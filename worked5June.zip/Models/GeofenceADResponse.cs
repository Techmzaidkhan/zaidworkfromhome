﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    public class GeofenceADResponse
    {
        public GeofenceADResponse()
        {
            points = new List<ADPoints>();
        }
        public string name { get; set; }
        public List<ADPoints> points { get; set; }
    }
    public class ADPoints
    {
        public double longitude { get; set; }
        public double latitude { get; set; }

    }

    public class ADGeofenceVehicleMappingResponse
    {
        public string id { get; set; }
        public string vehicleRegNo { get; set; }
        public string geoFenceName { get; set; }
        public string startDate { get; set; }
        public string endDate { get; set; }
        public string type { get; set; }
    }
}