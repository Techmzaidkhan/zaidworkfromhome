﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    #region    Vehicle Response
    public class VehicleADResponse
    {
    
        public string vehiclePlatform { get; set; }
        public string vehicleModel { get; set; }
        public string vehicleVariant { get; set; }
        public string vehicleRegNo { get; set; }
        public string status { get; set; }
        public string lastupdated { get; set; }
        public VehicleADlocation lastknownlocation { get; set; }
        public Boolean priorityAlertStatus { get; set; }
        public string address { get; set; }
        public string speed { get; set; }
        public string runningHours { get; set; }
        public string driverName { get; set; }
    }
    public class VehicleADlocation
    {
        public double longitude { get; set; }
        public double latitude { get; set; }

    }
    #endregion


    #region AD Vehicle Summary Response
    public class ADVehicleSummaryResponse
    {

        public string vehicleRegNo { get; set; }

        [JsonProperty(PropertyName = "vehicleLastUsedOn")]
        public string vehicleLastUsed { get; set; }

        [JsonProperty(PropertyName = "totalUsage")]
        public string totalUsage { get; set; }

        [JsonProperty(PropertyName = "vehicleRunningHours")]
        public string runninghours { get; set; }

        [JsonProperty(PropertyName = "vehicleIdleHours")]
        public string idlehours { get; set; }



    }
    #endregion


    #region   AD VehicleInformation Response
    public class ADVehicleInformationResponse
    {

        public string vehiclePlatform { get; set; }
        public string vehicleModel { get; set; }
        public string vehicleVariant { get; set; }
        public string vehicleRegNo { get; set; }

        [JsonProperty(PropertyName = "status")]
        public string vehicleStatus { get; set; }
        public string lastupdated { get; set; }

        //public string highEngineTemperature { get; set; }
        //public Int32 engineRPM { get; set; }
        //public string fuelLevel { get; set; }
        //public string vehicleHealth { get; set; }
        //public string fuelEfficiencyA { get; set; }
        //public string fuelEfficiencyB { get; set; }
        //public string averageVehicleSpeed { get; set; }
        //public string engineOilPressure { get; set; }
        //public string driverName { get; set; }


    }
    #endregion



    #region  AD Vehicle LocationHistory Response
    public class ADVehicleLocationHistoryResponse
    { 
        // public string registrationNumber { get; set; }
        public string speed { get; set; }
        // public Dictionary<string, string> location = new Dictionary<string, string>();
        public string address { get; set; }
        public VehicleADlocation location { get; set; }
        // public List<location> location = new List<location>();
        // [JsonProperty(PropertyName = "dateTime")]
        public string timeStamp { get; set; }

    }
    #endregion


    #region Single  Vehicle Alerts Response
    public class SingleADVehicleAlertsResponse
    {

        //public SingleVehicleAlertsResponse()
        //{
        //    location = new List<Models.location>();
        //}
        public string alertId { get; set; }
        public string alertName { get; set; }
        // public Dictionary<string, string> location = new Dictionary<string, string>();
        // public List<location> location { get; set; }
        public VehicleADlocation location { get; set; }
        public string priority { get; set; }
        public string dateTime { get; set; }

    }
    #endregion

    #region   Vehicle Alerts Response
    public class ADVehicleAlertsResponse
    {
        public string vehicleRegNo { get; set; }
        [JsonProperty(PropertyName = "alerts")]
        public List<SingleADVehicleAlertsResponse> SingleVehicleAlertsResponse = new List<SingleADVehicleAlertsResponse>();
    }
    #endregion
}