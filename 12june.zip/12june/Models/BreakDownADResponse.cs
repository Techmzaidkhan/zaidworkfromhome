﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    #region  AD 
    public class BreakDownADResponse
    {
            public double longitude { get; set; }

            public double latitude { get; set; }

            public string timestamp { get; set; }
        }
        #endregion
}
