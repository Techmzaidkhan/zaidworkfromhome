﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    public class UserADResponse
    {
        public AttributeAdInfo id { get; set; }
        public AttributeAdInfo firstName { get; set; }
        public AttributeAdInfo lastName { get; set; }
        public AttributeAdInfo contactNumber { get; set; }
        public AttributeAdInfo address { get; set; }
        public AttributeAdInfo idProof { get; set; }
        public AttributeAdInfo fileUrl { get; set; }
        public AttributeAdInfo email { get; set; }

    }
    public class AttributeAdInfo
    {
        public string value { get; set; }
        public string type { get; set; }
        public Boolean editable { get; set; }
    }
}