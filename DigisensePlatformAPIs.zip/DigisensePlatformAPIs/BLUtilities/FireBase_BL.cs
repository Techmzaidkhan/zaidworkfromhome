﻿using DigisensePlatformAPIs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.BLUtilities
{
    public class FireBase_BL
    {
     public static FireBasePushNoticationResponse PushNotification(string messageid)
        {
            FireBasePushNoticationResponse fireBase = new FireBasePushNoticationResponse();
            try
            {
                fireBase.message_id = messageid;
            }
            catch(Exception ex)
            {
                fireBase.message_id = ex.ToString();
            }
            return fireBase;
        }
    }
}