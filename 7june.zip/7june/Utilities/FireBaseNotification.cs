﻿using DigisensePlatformAPIs.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;

namespace DigisensePlatformAPIs.Utilities
{
    public class FireBaseNotification
    {

       
        public static string SendNotification(FireBasePushNotication fireBaseObj,string fcmapiServerkey,string senderId)
        {
            FCMPushNotification result = new FCMPushNotification();
            try
            {
                result.Successful = true;
                result.Error = null;
                var FCM_URI = "https://fcm.googleapis.com/fcm/send";
          
                var serializer = new JavaScriptSerializer();
                var json = serializer.Serialize(fireBaseObj);

                Byte[] byteArray = Encoding.UTF8.GetBytes(json);

                WebRequest request = WebRequest.Create(FCM_URI);
                // Set the Method property of the request to POST.  
                request.Method = "POST";
              
                request.Headers.Add(string.Format("Authorization: key={0}", fcmapiServerkey));
                request.Headers.Add(string.Format("Sender: id={0}", senderId));
            
                // Set the ContentType property of the WebRequest.  
                request.ContentType = "application/json";
                // Set the ContentLength property of the WebRequest.  
                request.ContentLength = byteArray.Length;
                // Get the request stream.  
                Stream dataStream = request.GetRequestStream();
                // Write the data to the request stream.  
                dataStream.Write(byteArray, 0, byteArray.Length);
                // Close the Stream object.  
                dataStream.Close();
                // Get the response.  
                WebResponse response = request.GetResponse();
                // Display the status.  
                Console.WriteLine(((HttpWebResponse)response).StatusDescription);
                // Get the stream containing content returned by the server.  
                dataStream = response.GetResponseStream();
                // Open the stream using a StreamReader for easy access.  
                StreamReader reader = new StreamReader(dataStream);
                // Read the content.  
                string responseFromServer = reader.ReadToEnd();
                // Display the content.  
                Console.WriteLine(responseFromServer);
                // Clean up the streams.  
                reader.Close();
                dataStream.Close();
                response.Close();
                result.Response = responseFromServer;

            }
            catch (Exception ex)
            {
                result.Successful = false;
                result.Response = null;
                result.Error = ex;
            }
            return Convert.ToString(result.Response);
        }
        
        /*
        public static string SendNotification(FireBasePushNotication fireBaseObj, string deviceID, string fcmapiServerkey, string senderId)
        {
            string address = string.Empty;
            try
            {
                string apiurl = "https://fcm.googleapis.com/fcm/send";
                // Create a request using a URL that can receive a post.   
                WebRequest request = WebRequest.Create(apiurl);
                // Set the Method property of the request to POST.  
                request.Method = "POST";
                // Create POST data and convert it to a byte array. 
                var postData = "{\"to\": \"/topics/Deviceid\",";
                postData += "\"data\": {    \"message\": \"This is a Firebase Cloud Messaging Topic Message!\",";
                postData += "}\n}";
                request.Headers.Add(string.Format("Authorization: key={0}", fcmapiServerkey));
                request.Headers.Add(string.Format("Sender: id={0}", senderId));
                byte[] byteArray = Encoding.UTF8.GetBytes(postData);
                // Set the ContentType property of the WebRequest.  
                request.ContentType = "application/json";
                // Set the ContentLength property of the WebRequest.  
                request.ContentLength = byteArray.Length;
                // Get the request stream.  
                Stream dataStream = request.GetRequestStream();
                // Write the data to the request stream.  
                dataStream.Write(byteArray, 0, byteArray.Length);
                // Close the Stream object.  
                dataStream.Close();
                // Get the response.  
                WebResponse response = request.GetResponse();
                // Display the status.  
                Console.WriteLine(((HttpWebResponse)response).StatusDescription);
                // Get the stream containing content returned by the server.  
                dataStream = response.GetResponseStream();
                // Open the stream using a StreamReader for easy access.  
                StreamReader reader = new StreamReader(dataStream);
                // Read the content.  
                string responseFromServer = reader.ReadToEnd();
                // Display the content.  
                Console.WriteLine(responseFromServer);
                // Clean up the streams.  
                reader.Close();
                dataStream.Close();
                response.Close();
                address = responseFromServer;
            }
            catch (Exception ex)
            {
                return address = ex.Message;
            }
            return address;
        }
        */
    }
}