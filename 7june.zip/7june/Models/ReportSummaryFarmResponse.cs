﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    public class ReportSummaryFarmResponse
    {
    }


    #region /report/platform/farm/vehiclemovement/usagehours/{vehicleRegNo}

    public class FarmVehicleUsageHours
    {
        public FarmVehicleUsageHoursData data { get; set; }
        public string chartType { get; set; }
        public FarmVehicleUsageHoursOptions options { get; set; }
    }
    public class FarmVehicleUsageHoursOptions
    {
        public bool responsive { get; set; }
        public bool maintainAspectRatio { get; set; }
        public FarmVehicleUsageHoursTitle title { get; set; }
    }

    public class FarmVehicleUsageHoursTitle
    {
        public bool display { get; set; }
        public string text { get; set; }
    }

    public class FarmVehicleUsageHoursData
    {
        public FarmVehicleUsageHoursData()
        {
            datasets = new List<FarmVehicleUsageHoursDataset>();
            labels = new List<string>();
        }
        public List<string> labels { get; set; }
        public List<FarmVehicleUsageHoursDataset> datasets { get; set; }
    }


    public class FarmVehicleUsageHoursDataset
    {
        public FarmVehicleUsageHoursDataset()
        {
            backgroundColor = new List<string>();
            data = new List<dynamic>();
        }
        public List<string> backgroundColor { get; set; }
        public string label { get; set; }
        public List<dynamic> data { get; set; }
    }

    #endregion


    #region Report Summary 8.02
    public class ReportSummaryFarm
    {
        public ReportSummaryFarm()
        {
            applicationjson = new List<ReportSummaryFarmApplicationJson>();
        }
        [JsonProperty("farmreports")]
        public List<ReportSummaryFarmApplicationJson> applicationjson { get; set; }
    }
    public class ReportSummaryFarmApplicationJson
    {
        public ReportSummaryFarmApplicationJson()
        {
            categories = new List<ReportSummaryFarmCategory>();
        }
        public string displayName { get; set; }
        public List<ReportSummaryFarmCategory> categories { get; set; }
    }
    public class ReportSummaryFarmCategory
    {
        public string url { get; set; }
        public string displayName { get; set; }
        public string type { get; set; }
    }

    #endregion

    #region api/report/platform/farm/vehiclemovement/vehicleutilization/{vehicleRegNo}

    public class FarmVehicleUtilization
    {
        public FarmVehicleUtilizationData data { get; set; }
        public string chartType { get; set; }
        public FarmVehicleUtilizationOptions options { get; set; }
    }
    public class FarmVehicleUtilizationOptions
    {
        public bool responsive { get; set; }
        public bool maintainAspectRatio { get; set; }
        public FarmVehicleUtilizationTitle title { get; set; }
    }
    public class FarmVehicleUtilizationTitle
    {
        public bool display { get; set; }
        public string text { get; set; }
    }

    public class FarmVehicleUtilizationData
    {
        public FarmVehicleUtilizationData()
        {
            datasets = new List<FarmVehicleUtilizationDataset>();
            labels = new List<string>();
        }
        public List<string> labels { get; set; }
        public List<FarmVehicleUtilizationDataset> datasets { get; set; }
    }

    public class FarmVehicleUtilizationDataset
    {
        public FarmVehicleUtilizationDataset()
        {
            data = new List<int>();
        }
        public string label { get; set; }
        public List<int> data { get; set; }
        public string backgroundColor { get; set; }
    }
    #endregion


    #region /report/platform/farm/vehiclemovement/enginehours/{vehicleRegNo}

    public class FarmEngineHours
    {
        public FarmEngineHoursData data { get; set; }
        public string chartType { get; set; }
        public FarmEngineHoursOptions options { get; set; }
    }

    public class FarmEngineHoursOptions
    {
        public bool responsive { get; set; }
        public bool maintainAspectRatio { get; set; }
        public FarmEngineHoursTitle title { get; set; }
    }
    
    public class FarmEngineHoursTitle
    {
        public bool display { get; set; }
        public string text { get; set; }
    }


    public class FarmEngineHoursData
    {
        public FarmEngineHoursData()
        {
            labels = new List<string>();
            datasets = new List<FarmEngineHoursDataset>();
        }
        public List<string> labels { get; set; }
        public List<FarmEngineHoursDataset> datasets { get; set; }
    }

    public class FarmEngineHoursDataset
    {
        public FarmEngineHoursDataset()
        {
            backgroundColor = new List<string>();
            data = new List<int>();
        }
        public List<string> backgroundColor { get; set; }
        public string label { get; set; }
        public List<int> data { get; set; }
    }


    #endregion


    #region /report/platform/farm/alerts/vehiclealerts/{vehicleRegNo}

    public class FarmVehicleAlertsDataset
    {
        public FarmVehicleAlertsDataset()
        {
            data = new List<int>();
        }
        public string label { get; set; }
        public List<int> data { get; set; }
        public string backgroundColor { get; set; }
    }

    public class FarmVehicleAlertsData
    {
        public FarmVehicleAlertsData()
        {
            datasets = new List<FarmVehicleAlertsDataset>();
            labels = new List<string>();
        }
        public List<string> labels { get; set; }
        public List<FarmVehicleAlertsDataset> datasets { get; set; }
    }

    public class FarmVehicleAlertsTitle
    {
        public bool display { get; set; }
        public string text { get; set; }
    }

    public class FarmVehicleAlertsOptions
    {
        public bool responsive { get; set; }
        public bool maintainAspectRatio { get; set; }
        public FarmVehicleAlertsTitle title { get; set; }
    }

    public class ReportSumamryFarmVehicleAlerts
    {
        public FarmVehicleAlertsData data { get; set; }
        public string chartType { get; set; }
        public FarmVehicleAlertsOptions options { get; set; }
    }
    #endregion


    #region /report/platform/farm/alerts/violation/{vehicleRegNo}

    public class FarmAlertViolationDataset
    {
        public FarmAlertViolationDataset()
        {
            data = new List<int>();
        }
        public string label { get; set; }
        public List<int> data { get; set; }
        public string backgroundColor { get; set; }
    }

    public class FarmAlertViolationData
    {
        public FarmAlertViolationData()
        {
            labels = new List<string>();
            datasets = new List<FarmAlertViolationDataset>();
        }
        public List<string> labels { get; set; }
        public List<FarmAlertViolationDataset> datasets { get; set; }
    }

    public class FarmAlertViolationTitle
    {
        public bool display { get; set; }
        public string text { get; set; }
    }

    public class FarmAlertViolationOptions
    {
        public bool responsive { get; set; }
        public bool maintainAspectRatio { get; set; }
        public FarmAlertViolationTitle title { get; set; }
    }

    public class FarmAlertViolation
    {
        public FarmAlertViolationData data { get; set; }
        public string chartType { get; set; }
        public FarmAlertViolationOptions options { get; set; }
    }

    #endregion
}