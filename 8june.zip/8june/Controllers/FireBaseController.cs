﻿using DigisensePlatformAPIs.BLUtilities;
using DigisensePlatformAPIs.Models;
using DigisensePlatformAPIs.Utilities;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace DigisensePlatformAPIs.Controllers
{
    public class FireBaseController : ApiController
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #region Reset Password

        [HttpPost]
        [Route("api/Firebase/PushNotification")]
        public HttpResponseMessage PushNotifications([FromBody]FireBasePushNotication pushNotificationObj)
        {
            System.Net.Http.Headers.HttpRequestHeaders headers = this.Request.Headers;
            string fcmapiServerkey = string.Empty;
            string senderId = string.Empty;
            if (pushNotificationObj == null)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, BLUtilities.Common_BL.Response("Invalid parameters"));
            }
            if (!ModelState.IsValid)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, BLUtilities.Common_BL.Response("Invalid parameters"));
            }
            if (headers.Contains("authorization"))
            {
                if (headers.GetValues("authorization") != null && Convert.ToString(headers.GetValues("authorization")) != "")
                {
                    fcmapiServerkey = headers.GetValues("authorization").First();
                }
            }
            if (headers.Contains("sender"))
            {
                if (headers.GetValues("sender") != null && Convert.ToString(headers.GetValues("sender")) != "")
                {
                    senderId = headers.GetValues("sender").First();
                }
            }
            if (senderId == string.Empty)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, BLUtilities.Common_BL.Response("Sender key required"));
            }
            if (fcmapiServerkey == string.Empty)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, BLUtilities.Common_BL.Response("Authorization key required"));
            }

            try
            {
                var message = FireBaseNotification.SendNotification(pushNotificationObj,fcmapiServerkey,senderId);
                if (message != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, BLUtilities.FireBase_BL.PushNotification(message));
                }
                else
                {
                    Log.Error("Message not sent due to no access of server");
                    return Request.CreateResponse(HttpStatusCode.BadRequest, BLUtilities.Common_BL.Response("Message not sent due to no access of server"));
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return Request.CreateResponse(HttpStatusCode.BadRequest, BLUtilities.Common_BL.Response(ex.Message));
            }
        }

        #endregion
        
    }
}
