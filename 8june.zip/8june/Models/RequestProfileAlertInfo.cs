﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    public class RequestProfileAlertInfo
    {
        [Required]
        public string field { get; set; }
        [Required]
        public string value { get; set; }
        [Required]
        public string unit { get; set; }

    }
}