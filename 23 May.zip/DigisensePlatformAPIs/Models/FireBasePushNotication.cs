﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    public class FireBasePushNotication
    {
        public string to { get; set; }
        public Data data { get; set; }
    }
    public class Data
    {
        public string message { get; set; }
    }
}