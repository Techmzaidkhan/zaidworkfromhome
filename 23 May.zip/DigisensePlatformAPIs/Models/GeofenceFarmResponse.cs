﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    public class GeofenceFarmResponse
    {
        public GeofenceFarmResponse()
        {
            points = new List<FarmPoints>();
        }
            public string name { get; set; }
            public List<FarmPoints> points { get; set; }
        }

        public class GeofenceFarmPointsListResponse
        {
            public FarmPoints points { get; set; }
        }
        public class FarmPoints
        {
            public double longitude { get; set; }
            public double latitude { get; set; }
        }



    public class GeofenceFarmVehicleMappingResponse
    {
        public string id { get; set; }
        public string vehicleRegNo { get; set; }
        public string geoFenceName { get; set; }
        public string startDate { get; set; }
        public string endDate { get; set; }
        public string type { get; set; }
    }
}