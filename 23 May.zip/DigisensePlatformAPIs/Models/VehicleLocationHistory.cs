﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    public class VehicleLocationHistory
    {
        public string vehregno { get; set; }
        public string startdate { get; set; }
        public string enddate { get; set; }
    }
}