﻿using Microsoft.Web.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Cors;
 
namespace DigisensePlatformAPIs
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
           // log4net.Config.XmlConfigurator.Configure();
            var cors = new EnableCorsAttribute("*", "*", "*");
            config.EnableCors(cors);
            config.MapHttpAttributeRoutes();
            
            config.Routes.MapHttpRoute(
            name: "Error404",
            routeTemplate: "{*url}",
            defaults: new { controller = "Error", action = "Handle404" }
            );


            // added API Versions
            config.AddApiVersioning(o =>
            {
                o.ReportApiVersions = true;
                o.AssumeDefaultVersionWhenUnspecified = true;
                // o.DefaultApiVersion = new ApiVersion(new DateTime( 2017, 5, 23 ) ,1, 1);
                o.DefaultApiVersion = new ApiVersion(1, 0);
            });
        }
    }
}
