﻿using DigisensePlatformAPIs.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.BLUtilities
{
    public class User_BL
    {
        #region MTBD
        #region    User Response
        public static List<UserResponse> UserResponse(DataTable dt)
        {
            UserResponse clsUserResponse = null;



            List<UserResponse> list = new List<UserResponse>();

            byte[] emptyByte = { };
            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    clsUserResponse = new UserResponse();


                    clsUserResponse.id = new AttributeInfo { value = dt.Rows[i]["id"].ToString(), type = "", editable = false };
                    clsUserResponse.firstName = new AttributeInfo { value = dt.Rows[i]["firstname"].ToString(), type = "", editable = true };
                    clsUserResponse.lastName = new AttributeInfo { value = dt.Rows[i]["lastname"].ToString(), type = "", editable = true };
                    clsUserResponse.contactNumber = new AttributeInfo { value = dt.Rows[i]["contactNumber"].ToString(), type = "", editable = true };
                    clsUserResponse.address = new AttributeInfo { value = dt.Rows[i]["Address"].ToString(), type = "", editable = true };
                    clsUserResponse.idProof = new AttributeInfo { value = "", type = "", editable = false };
                    clsUserResponse.fileUrl = new AttributeInfo { value = "", type = "", editable = false };
                    clsUserResponse.email = new AttributeInfo { value = dt.Rows[i]["email"].ToString(), type = "", editable = true };

                    list.Add(clsUserResponse);

                }
                return list;
            }
            catch (Exception ex)
            {
                return list;
            }
        }

        #endregion

        #endregion


        #region Farm 

        #region Farm Get
        public static List<UserFarmResponse> FarmUserResponse(DataTable dt)
        {
            UserFarmResponse clsUserResponse = null;



            List<UserFarmResponse> list = new List<UserFarmResponse>();

            byte[] emptyByte = { };
            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    clsUserResponse = new UserFarmResponse();


                    clsUserResponse.id = new AttributeInfo { value = dt.Rows[i]["id"].ToString(), type = "", editable = false };
                    clsUserResponse.firstName = new AttributeInfo { value = dt.Rows[i]["firstname"].ToString(), type = "", editable = true };
                    clsUserResponse.lastName = new AttributeInfo { value = dt.Rows[i]["lastname"].ToString(), type = "", editable = true };
                    clsUserResponse.contactNumber = new AttributeInfo { value = dt.Rows[i]["contactNumber"].ToString(), type = "", editable = true };
                    clsUserResponse.address = new AttributeInfo { value = dt.Rows[i]["Address"].ToString(), type = "", editable = true };
                    clsUserResponse.idProof = new AttributeInfo { value = "", type = "", editable = false };
                    clsUserResponse.fileUrl = new AttributeInfo { value = "", type = "", editable = false };
                    clsUserResponse.email = new AttributeInfo { value = dt.Rows[i]["email"].ToString(), type = "", editable = true };

                    list.Add(clsUserResponse);

                }
                return list;
            }
            catch (Exception ex)
            {
                return list;
            }
        }


        #endregion

        #region    User Response
        public static List<UserFarmResponse> UserFarmResponse(DataTable dt)
        {
            UserFarmResponse clsUserResponse = null;



            List<UserFarmResponse> list = new List<UserFarmResponse>();

            byte[] emptyByte = { };
            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    clsUserResponse = new UserFarmResponse();


                    clsUserResponse.id = new AttributeInfo { value = dt.Rows[i]["userid"].ToString(), type = "", editable = false };
                    clsUserResponse.firstName = new AttributeInfo { value = dt.Rows[i]["firstname"].ToString(), type = "", editable = true };
                    clsUserResponse.lastName = new AttributeInfo { value = dt.Rows[i]["lastname"].ToString(), type = "", editable = true };
                    clsUserResponse.contactNumber = new AttributeInfo { value = dt.Rows[i]["contactNumber"].ToString(), type = "", editable = true };
                    clsUserResponse.address = new AttributeInfo { value = dt.Rows[i]["Address"].ToString(), type = "", editable = true };
                    clsUserResponse.idProof = new AttributeInfo { value = "", type = "", editable = false };
                    clsUserResponse.fileUrl = new AttributeInfo { value = "", type = "", editable = false };
                    clsUserResponse.email = new AttributeInfo { value = dt.Rows[i]["email"].ToString(), type = "", editable = true };

                    list.Add(clsUserResponse);

                }
                return list;
            }
            catch (Exception ex)
            {
                return list;
            }
        }

        #endregion
        
        #endregion


        #region AD

        #region AD Get
        public static List<UserADResponse> ADUserResponse(DataTable dt)
        {
            UserADResponse clsUserResponse = null;



            List<UserADResponse> list = new List<UserADResponse>();

            byte[] emptyByte = { };
            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    clsUserResponse = new UserADResponse();


                    clsUserResponse.id = new AttributeAdInfo { value = dt.Rows[i]["userid"].ToString(), type = "", editable = false };
                    clsUserResponse.firstName = new AttributeAdInfo { value = dt.Rows[i]["firstname"].ToString(), type = "", editable = true };
                    clsUserResponse.lastName = new AttributeAdInfo { value = dt.Rows[i]["lastname"].ToString(), type = "", editable = true };
                    clsUserResponse.contactNumber = new AttributeAdInfo { value = dt.Rows[i]["contactNumber"].ToString(), type = "", editable = true };
                    clsUserResponse.address = new AttributeAdInfo { value = dt.Rows[i]["Address"].ToString(), type = "", editable = true };
                    clsUserResponse.idProof = new AttributeAdInfo { value = "", type = "", editable = false };
                    clsUserResponse.fileUrl = new AttributeAdInfo { value = "", type = "", editable = false };
                    clsUserResponse.email = new AttributeAdInfo { value = dt.Rows[i]["email"].ToString(), type = "", editable = true };

                    list.Add(clsUserResponse);

                }
                return list;
            }
            catch (Exception ex)
            {
                return list;
            }
        }


        #endregion


   
        #endregion
    }
}