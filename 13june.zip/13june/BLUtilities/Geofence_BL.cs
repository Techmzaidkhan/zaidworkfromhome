﻿using DigisensePlatformAPIs.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.BLUtilities
{
    public class Geofence_BL
    {

        #region Mtbd Geofence 
        #region  Geofence Response
        public static GeofenceResponse  GeofenceResponse(DataTable dt)
        {
            GeofenceResponse clsGeofenceResponse = null;


            points clsGeofencePointsListResponse = null;
            List<points> list;

 
            try
            {
                clsGeofenceResponse = new GeofenceResponse();
             
                clsGeofenceResponse.name = dt.Rows[0]["geofence_name"].ToString();
                string[] latlng = dt.Rows[0]["geo_boundary_data"].ToString().Split(',');
                list = new List<points>();
                for (int i = 0; i < latlng.Length; i=i+2)
                {
                    clsGeofencePointsListResponse = new points();
                    clsGeofencePointsListResponse.latitude= latlng[i].ToString() == "" ? 180 : Convert.ToDouble(latlng[i].ToString());
                    clsGeofencePointsListResponse.longitude = latlng[i + 1].ToString() == "" ? 180 : Convert.ToDouble(latlng[i + 1].ToString());

                    list.Add(clsGeofencePointsListResponse);
                }
                clsGeofenceResponse.points = list;
                return clsGeofenceResponse;
            }
            catch (Exception ex)
            {
                return clsGeofenceResponse;
            }
        }
        #endregion

        #region List Geofence Response
        public static List<GeofenceResponse> GeofenceAllResponse(DataTable dt)
        {
            GeofenceResponse clsGeofenceResponse = null;

            List<GeofenceResponse> finallist = new List<GeofenceResponse>();
            points clsGeofencePointsListResponse = null;
            List<points> list;


            try
            {
             
                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    clsGeofenceResponse = new GeofenceResponse();
                    list = new List<points>();
                    clsGeofenceResponse.name = dt.Rows[n]["geofence_name"].ToString();
                    string[] latlng = dt.Rows[n]["geo_boundary_data"].ToString().Split(',');

                    for (int i = 0; i < latlng.Length; i = i + 2)
                    {
                        clsGeofencePointsListResponse = new points();
                        clsGeofencePointsListResponse.latitude = latlng[i].ToString() == "" ? 180 : Convert.ToDouble(latlng[i].ToString());
                        clsGeofencePointsListResponse.longitude = latlng[i + 1].ToString() == "" ? 180 : Convert.ToDouble(latlng[i + 1].ToString());

                        list.Add(clsGeofencePointsListResponse);
                    }
                    clsGeofenceResponse.points = list;

                    finallist.Add(clsGeofenceResponse);
                }
                return finallist;
            }
            catch (Exception ex)
            {
                return finallist;
            }
        }
        #endregion

        #region List Geofence Vehicle Mapping Response
        public static List<GeofenceVehicleMappingResponse> GeofenceVehicleMappingResponse(DataTable dt)
        {
            GeofenceVehicleMappingResponse clsGeofenceVehicleMappingResponse = null;

            List<GeofenceVehicleMappingResponse> finallist = new List<GeofenceVehicleMappingResponse>();
           
            try
            {

                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    clsGeofenceVehicleMappingResponse = new GeofenceVehicleMappingResponse();

                    clsGeofenceVehicleMappingResponse.id = dt.Rows[n]["GeofenceID"].ToString();
                    clsGeofenceVehicleMappingResponse.vehicleRegNo = dt.Rows[n]["RegistrationNumber"].ToString();
                    clsGeofenceVehicleMappingResponse.geoFenceName = dt.Rows[n]["geofencename"].ToString();
                    clsGeofenceVehicleMappingResponse.startDate = Convert.ToDateTime(dt.Rows[n]["StartDate"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    clsGeofenceVehicleMappingResponse.endDate = Convert.ToDateTime(dt.Rows[n]["EndDate"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    clsGeofenceVehicleMappingResponse.type = dt.Rows[n]["Type"].ToString();

                    finallist.Add(clsGeofenceVehicleMappingResponse);
                }
                return finallist;
            }
            catch (Exception ex)
            {
                return finallist;
            }
        }
        #endregion

        #endregion


        #region Farm GeoFence 

        #region    Create  Geofence Response
        public static List<GeofenceFarmResponse> GeofenceFarmAllResponse(DataTable dt)
        {
            GeofenceFarmResponse clsGeofenceResponse = null;

            List<GeofenceFarmResponse> finallist = new List<GeofenceFarmResponse>();
            FarmPoints clsGeofencePointsListResponse = null;
            List<FarmPoints> list;


            try
            {

                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    clsGeofenceResponse = new GeofenceFarmResponse();
                    list = new List<FarmPoints>();
                    clsGeofenceResponse.name = dt.Rows[n]["geofence_name"].ToString();
                    string[] latlng = dt.Rows[n]["geo_boundary_data"].ToString().Split(',');

                    for (int i = 0; i < latlng.Length; i = i + 2)
                    {
                        clsGeofencePointsListResponse = new FarmPoints();
                        clsGeofencePointsListResponse.latitude = latlng[i].ToString() == "" ? 180 : Convert.ToDouble(latlng[i].ToString());
                        clsGeofencePointsListResponse.longitude = latlng[i + 1].ToString() == "" ? 180 : Convert.ToDouble(latlng[i + 1].ToString());

                        list.Add(clsGeofencePointsListResponse);
                    }
                    clsGeofenceResponse.points = list;

                    finallist.Add(clsGeofenceResponse);
                }
                return finallist;
            }
            catch (Exception ex)
            {
                return finallist;
            }
        }
        #endregion

        #region  Get All Geofence List

        #region List Geofence Response
        public static List<GeofenceFarmResponse> GeofenceFarmListResponse(DataTable dt)
        {
            GeofenceFarmResponse clsGeofenceResponse = null;

            List<GeofenceFarmResponse> finallist = new List<GeofenceFarmResponse>();
            FarmPoints clsGeofencePointsListResponse = null;
            List<FarmPoints> list;


            try
            {

                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    clsGeofenceResponse = new GeofenceFarmResponse();
                    list = new List<FarmPoints>();
                    clsGeofenceResponse.name = dt.Rows[n]["geofence_name"].ToString();
                    string[] latlng = dt.Rows[n]["geo_boundary_data"].ToString().Split(',');

                    for (int i = 0; i < latlng.Length; i = i + 2)
                    {
                        clsGeofencePointsListResponse = new FarmPoints();
                        clsGeofencePointsListResponse.latitude = latlng[i].ToString() == "" ? 180 : Convert.ToDouble(latlng[i].ToString());
                        clsGeofencePointsListResponse.longitude = latlng[i + 1].ToString() == "" ? 180 : Convert.ToDouble(latlng[i + 1].ToString());

                        list.Add(clsGeofencePointsListResponse);
                    }
                    clsGeofenceResponse.points = list;

                    finallist.Add(clsGeofenceResponse);
                }
                return finallist;
            }
            catch (Exception ex)
            {
                return finallist;
            }
        }
        #endregion
        #endregion
        
        #region List Geofence Response
        public static List<GeofenceFarmResponse> GeofenceFarmForSpecificResponse(DataTable dt)
        {
            GeofenceFarmResponse clsGeofenceResponse = null;

            List<GeofenceFarmResponse> finallist = new List<GeofenceFarmResponse>();
            FarmPoints clsGeofencePointsListResponse = null;
            List<FarmPoints> list;


            try
            {

                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    clsGeofenceResponse = new GeofenceFarmResponse();
                    list = new List<FarmPoints>();
                    clsGeofenceResponse.name = dt.Rows[n]["geofence_name"].ToString();
                    string[] latlng = dt.Rows[n]["geo_boundary_data"].ToString().Split(',');

                    for (int i = 0; i < latlng.Length; i = i + 2)
                    {
                        clsGeofencePointsListResponse = new FarmPoints();
                        clsGeofencePointsListResponse.latitude = latlng[i].ToString() == "" ? 180 : Convert.ToDouble(latlng[i].ToString());
                        clsGeofencePointsListResponse.longitude = latlng[i + 1].ToString() == "" ? 180 : Convert.ToDouble(latlng[i + 1].ToString());

                        list.Add(clsGeofencePointsListResponse);
                    }
                    clsGeofenceResponse.points = list;

                    finallist.Add(clsGeofenceResponse);
                }
                return finallist;
            }
            catch (Exception ex)
            {
                return finallist;
            }
        }
        #endregion
        
        #region Response for Update

     
        public static List<GeofenceFarmResponse> FarmUpdateResponse(DataTable dt)
        {
            GeofenceFarmResponse clsGeofenceResponse = null;

            List<GeofenceFarmResponse> finallist = new List<GeofenceFarmResponse>();
            FarmPoints clsGeofencePointsListResponse = null;
            List<FarmPoints> list;


            try
            {

                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    clsGeofenceResponse = new GeofenceFarmResponse();
                    list = new List<FarmPoints>();
                    clsGeofenceResponse.name = dt.Rows[n]["geofence_name"].ToString();
                    string[] latlng = dt.Rows[n]["geo_boundary_data"].ToString().Split(',');

                    for (int i = 0; i < latlng.Length; i = i + 2)
                    {
                        clsGeofencePointsListResponse = new FarmPoints();
                        clsGeofencePointsListResponse.latitude = latlng[i].ToString() == "" ? 180 : Convert.ToDouble(latlng[i].ToString());
                        clsGeofencePointsListResponse.longitude = latlng[i + 1].ToString() == "" ? 180 : Convert.ToDouble(latlng[i + 1].ToString());

                        list.Add(clsGeofencePointsListResponse);
                    }
                    clsGeofenceResponse.points = list;

                    finallist.Add(clsGeofenceResponse);
                }
                return finallist;
            }
            catch (Exception ex)
            {
                return finallist;
            }
        }
        #endregion

        #region List Farm Geofence Vehicle Mapping Response Get
        public static List<GeofenceFarmVehicleMappingResponse> FarmGeofenceVehicleMappingResponse(DataTable dt)
        {
            GeofenceFarmVehicleMappingResponse clsGeofenceVehicleMappingResponse = null;

            List<GeofenceFarmVehicleMappingResponse> finallist = new List<GeofenceFarmVehicleMappingResponse>();

            try
            {

                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    clsGeofenceVehicleMappingResponse = new GeofenceFarmVehicleMappingResponse();
                    clsGeofenceVehicleMappingResponse.id = dt.Rows[n]["GeofenceID"].ToString();
                    clsGeofenceVehicleMappingResponse.vehicleRegNo = dt.Rows[n]["RegistrationNumber"].ToString();
                    clsGeofenceVehicleMappingResponse.geoFenceName = dt.Rows[n]["geofencename"].ToString();
                    clsGeofenceVehicleMappingResponse.startDate = Convert.ToDateTime(dt.Rows[n]["startdate"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    clsGeofenceVehicleMappingResponse.endDate = Convert.ToDateTime(dt.Rows[n]["enddate"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    clsGeofenceVehicleMappingResponse.type = dt.Rows[n]["type"].ToString();

                    finallist.Add(clsGeofenceVehicleMappingResponse);
                }
                return finallist;
            }
            catch (Exception ex)
            {
                return finallist;
            }
        }
        #endregion

        #region GET List Farm Geofence Vehicle Mapping Response Active 
        public static List<GeofenceFarmVehicleMappingResponse> FarmVehicleMappingGetActiveGeofence(DataTable dt)
        {
            GeofenceFarmVehicleMappingResponse clsGeofenceVehicleMappingResponse = null;

            List<GeofenceFarmVehicleMappingResponse> finallist = new List<GeofenceFarmVehicleMappingResponse>();

            try
            {

                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    clsGeofenceVehicleMappingResponse = new GeofenceFarmVehicleMappingResponse();
                    clsGeofenceVehicleMappingResponse.id = dt.Rows[n]["GeofenceID"].ToString();
                    clsGeofenceVehicleMappingResponse.vehicleRegNo = dt.Rows[n]["RegistrationNumber"].ToString();
                    clsGeofenceVehicleMappingResponse.geoFenceName = dt.Rows[n]["geofencename"].ToString();
                    clsGeofenceVehicleMappingResponse.startDate = Convert.ToDateTime(dt.Rows[n]["startdate"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    clsGeofenceVehicleMappingResponse.endDate = Convert.ToDateTime(dt.Rows[n]["enddate"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    clsGeofenceVehicleMappingResponse.type = dt.Rows[n]["type"].ToString();

                    finallist.Add(clsGeofenceVehicleMappingResponse);
                }
                return finallist;
            }
            catch (Exception ex)
            {
                return finallist;
            }
        }
        #endregion

        #region List Farm Geofence Vehicle Mapping Response Get
        public static List<GeofenceFarmVehicleMappingResponse> FarmMappingForInsertResponse(DataTable dt)
        {
            GeofenceFarmVehicleMappingResponse clsGeofenceVehicleMappingResponse = null;

            List<GeofenceFarmVehicleMappingResponse> finallist = new List<GeofenceFarmVehicleMappingResponse>();

            try
            {

                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    clsGeofenceVehicleMappingResponse = new GeofenceFarmVehicleMappingResponse();
                    clsGeofenceVehicleMappingResponse.id = dt.Rows[n]["GeofenceID"].ToString();
                    clsGeofenceVehicleMappingResponse.vehicleRegNo = dt.Rows[n]["RegistrationNumber"].ToString();
                    clsGeofenceVehicleMappingResponse.geoFenceName = dt.Rows[n]["geofencename"].ToString();
                    clsGeofenceVehicleMappingResponse.startDate = Convert.ToDateTime(dt.Rows[n]["startdate"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    clsGeofenceVehicleMappingResponse.endDate = Convert.ToDateTime(dt.Rows[n]["enddate"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    clsGeofenceVehicleMappingResponse.type = dt.Rows[n]["type"].ToString();

                    finallist.Add(clsGeofenceVehicleMappingResponse);
                }
                return finallist;
            }
            catch (Exception ex)
            {
                return finallist;
            }
        }
        #endregion


        #endregion



        #region AD 


        #region List Geofence Response
        public static List<GeofenceADResponse> ADGeofenceAllResponse(DataTable dt)
        {
            GeofenceADResponse clsGeofenceResponse = null;

            List<GeofenceADResponse> finallist = new List<GeofenceADResponse>();
            ADPoints clsGeofencePointsListResponse = null;
            List<ADPoints> list;


            try
            {

                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    clsGeofenceResponse = new GeofenceADResponse();
                    list = new List<ADPoints>();
                    clsGeofenceResponse.name = dt.Rows[n]["geofence_name"].ToString();
                    string[] latlng = dt.Rows[n]["geo_boundary_data"].ToString().Split(',');

                    for (int i = 0; i < latlng.Length; i = i + 2)
                    {
                        clsGeofencePointsListResponse = new ADPoints();
                        clsGeofencePointsListResponse.latitude = latlng[i].ToString() == "" ? 180 : Convert.ToDouble(latlng[i].ToString());
                        clsGeofencePointsListResponse.longitude = latlng[i + 1].ToString() == "" ? 180 : Convert.ToDouble(latlng[i + 1].ToString());

                        list.Add(clsGeofencePointsListResponse);
                    }
                    clsGeofenceResponse.points = list;

                    finallist.Add(clsGeofenceResponse);
                }
                return finallist;
            }
            catch (Exception ex)
            {
                return finallist;
            }
        }
        #endregion


        #region List Geofence Vehicle Mapping Response
        public static List<ADGeofenceVehicleMappingResponse> ADGeofenceVehicleMappingResponse(DataTable dt)
        {
            ADGeofenceVehicleMappingResponse clsGeofenceVehicleMappingResponse = null;

            List<ADGeofenceVehicleMappingResponse> finallist = new List<ADGeofenceVehicleMappingResponse>();

            try
            {

                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    clsGeofenceVehicleMappingResponse = new ADGeofenceVehicleMappingResponse();

                    clsGeofenceVehicleMappingResponse.id = dt.Rows[n]["GeofenceID"].ToString();
                    clsGeofenceVehicleMappingResponse.vehicleRegNo = dt.Rows[n]["RegistrationNumber"].ToString();
                    clsGeofenceVehicleMappingResponse.geoFenceName = dt.Rows[n]["geofencename"].ToString();
                    clsGeofenceVehicleMappingResponse.startDate = Convert.ToDateTime(dt.Rows[n]["StartDate"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    clsGeofenceVehicleMappingResponse.endDate = Convert.ToDateTime(dt.Rows[n]["EndDate"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    clsGeofenceVehicleMappingResponse.type = dt.Rows[n]["Type"].ToString();

                    finallist.Add(clsGeofenceVehicleMappingResponse);
                }
                return finallist;
            }
            catch (Exception ex)
            {
                return finallist;
            }
        }
        #endregion


        #region List Geofence Vehicle Mapping Response
        public static List<ADGeofenceVehicleMappingResponse> ADGeofenceVehicleResponse(DataTable dt)
        {
            ADGeofenceVehicleMappingResponse clsGeofenceVehicleMappingResponse = null;

            List<ADGeofenceVehicleMappingResponse> finallist = new List<ADGeofenceVehicleMappingResponse>();

            try
            {

                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    clsGeofenceVehicleMappingResponse = new ADGeofenceVehicleMappingResponse();

                    clsGeofenceVehicleMappingResponse.id = dt.Rows[n]["GeofenceID"].ToString();
                    clsGeofenceVehicleMappingResponse.vehicleRegNo = dt.Rows[n]["RegistrationNumber"].ToString();
                    clsGeofenceVehicleMappingResponse.geoFenceName = dt.Rows[n]["geofencename"].ToString();
                    clsGeofenceVehicleMappingResponse.startDate = Convert.ToDateTime(dt.Rows[n]["StartDate"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    clsGeofenceVehicleMappingResponse.endDate = Convert.ToDateTime(dt.Rows[n]["EndDate"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    clsGeofenceVehicleMappingResponse.type = dt.Rows[n]["Type"].ToString();

                    finallist.Add(clsGeofenceVehicleMappingResponse);
                }
                return finallist;
            }
            catch (Exception ex)
            {
                return finallist;
            }
        }
        #endregion



        #endregion
    }
}