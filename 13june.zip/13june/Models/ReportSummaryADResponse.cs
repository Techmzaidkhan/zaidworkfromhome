﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    //public class ReportSummaryADResponse
    //{


    //}

    #region Report Summary 8.02
    public class ReportSummaryADResponse
    {
        public ReportSummaryADResponse()
        {
            applicationjson = new List<ReportSummaryADResponseApplicationJson>();
        }
        [JsonProperty("application/json")]
        public List<ReportSummaryADResponseApplicationJson> applicationjson { get; set; }
    }
    public class ReportSummaryADResponseApplicationJson
    {
        public ReportSummaryADResponseApplicationJson()
        {
            categories = new List<ReportSummaryADResponseCategory>();
        }
        public string displayName { get; set; }
        public List<ReportSummaryADResponseCategory> categories { get; set; }
    }
    public class ReportSummaryADResponseCategory
    {
        public string url { get; set; }
        public string displayName { get; set; }
    }

    #endregion
}