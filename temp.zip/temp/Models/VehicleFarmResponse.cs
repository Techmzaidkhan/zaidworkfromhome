﻿using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    public class VehicleFarmResponse
    {
        public string vehiclePlatform { get; set; }
        public string vehicleModel { get; set; }
        public string vehicleVariant { get; set; }
        public string vehicleRegNo { get; set; }
        public string status { get; set; }
        public string lastupdated { get; set; }
        public VehicleFarmLocation lastknownlocation { get; set; }
        public Boolean priorityAlertStatus { get; set; }
        public string address { get; set; }
        public string runningHours { get; set; }

    }
    public class VehicleFarmLocation
    {
        public double longitude { get; set; }
        public double latitude { get; set; }
    }


    #region farm Single  Vehicle Alerts Response
    public class SingleFarmVehicleAlertsResponse
    {

        //public SingleVehicleAlertsResponse()
        //{
        //    location = new List<Models.location>();
        //}
        public string alertId { get; set; }
        public string alertName { get; set; }
        // public Dictionary<string, string> location = new Dictionary<string, string>();
        // public List<location> location { get; set; }
        public Vehiclelocation location { get; set; }
        public string priority { get; set; }
        public string dateTime { get; set; }

    }
    #endregion

    #region  Vehicle Farm Summary Response
    public class VehicleFarmSummaryResponse
    {

        public string vehicleRegNo { get; set; }
        [JsonProperty(PropertyName = "vehicleLastUsedOn")]
        public string vehicleLastUsed { get; set; }

    }
    #endregion


    #region   Vehicle Farm Alerts Response
    public class VehicleFarmAlertsResponse
    {
        public string vehicleRegNo { get; set; }
        [JsonProperty(PropertyName = "alerts")]
        // public SingleVehicleAlertsResponse SingleVehicleAlertsResponse { get; set; }
        public List<SingleFarmVehicleAlertsResponse> SingleVehicleAlertsResponse = new List<SingleFarmVehicleAlertsResponse>();
    }
    #endregion




    public class VehicleFarmInformationResponse
    {

        public string vehicleRegNo { get; set; }
        public string vehicleStatus { get; set; }
        public string lastUpdated { get; set; }


    }


    #region   Vehicle LocationHistory Response
    public class VehicleFarmLocationHistoryResponse
    {
        public string speed { get; set; }
        public string address { get; set; }
        public Vehiclelocation location { get; set; }
        public string timeStamp { get; set; }
    }
    #endregion



    #region Live Vehicle Farm
  
    public class FarmLiveVehicleInformationResponse
    {

        public string vehiclePlatform { get; set; }
        public string vehicleModel { get; set; }
        public string vehicleVariant { get; set; }
        public string vehicleRegNo { get; set; }

        [JsonProperty(PropertyName = "status")]
        public string vehicleStatus { get; set; }
        public string lastupdated { get; set; }

    }
    #endregion
}